<?php
session_start();
$id = $_SESSION['id'];
if ($id == "") {
    echo "<script>window.location.href='login.php'</script>";
}
include("includes/connection.php");
if (isset($_POST['save'])) {
    $customer_name = htmlspecialchars($_POST['customer_name']);
    $customer_address = htmlspecialchars($_POST['customer_address']);
    $dates = htmlspecialchars($_POST['date_in']);
    $invoice_no = htmlspecialchars($_POST['invoice_no']);
    $payment_type = htmlspecialchars($_POST['payment_type']);
    $medicine_name = htmlspecialchars($_POST['medicine_name']);
    $quantity = htmlspecialchars($_POST['quantity']);
    $discount = htmlspecialchars($_POST['discount']);
    $select = mysqli_query($connection, "SELECT * FROM `medicines_stock` WHERE NAME='$medicine_name'");
    $fetch = mysqli_fetch_array($select);
    $quantitys = $fetch['QUANTITY'];
    if ($quantitys >= $quantity) {
        $rate = $fetch['RATE'];
        $amount = $rate * $quantity;
        $customer = $customer_name . "- " . $customer_address;
        $total_amount = $amount - $discount;
        $update = mysqli_query($connection, "");
        $insert_stock = mysqli_query($connection, "INSERT INTO `invoices`( `NET_TOTAL`, `INVOICE_DATE`, `CUSTOMER_ID`, `TOTAL_AMOUNT`, `TOTAL_DISCOUNT`) 
    VALUES ('$amount','$dates','$customer','$total_amount','$discount')");
        if ($insert_stock) {
            $final = $quantitys - $quantity;
            $update = mysqli_query($connection, "UPDATE `medicines_stock` SET `QUANTITY`='$final' WHERE NAME='$medicine_name'");
            echo "<script>alert('Invoice Succefully');</script>";
        } else {
            echo "<script>alert('Oops!! Something wrong happen,Try Again')</script>";
        }
    } else {
        echo "<script>alert('Oops!! Quantity is not sufficient')</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Pharmacy System || Add Invoice</title>
    <!-- include all link & script up Here-->
    <?php include("includes/script_up.php"); ?>
</head>

<body>
    <!-- include toggle botton Nav links Here -->
    <?php include("includes/side_nav_toggle.php"); ?>
    <!-- Home page dashboard Here -->
    <div class="container-fluid">
        <div class="row content">
            <div class="col-sm-3 sidenav hidden-xs">
                <?php include("includes/side_bar.php"); ?>
            </div>
            <br>

            <div class="col-sm-9">
                <div class="well">
                    <h4>Pharmacy Name Here || <small>Add Invoice</small></h4>
                </div>
                <div class="row">
                    <form action="" method="post">
                        <div class="col-sm-12">
                            <div class="well">
                                <!-- add user form here -->
                                <div class="row">
                                    <div class="col-md-3 col-lg-3 col-sm-12">
                                        <label for="">Customer Name</label>
                                        <input type="text" id="" class="form-control" name="customer_name" required>
                                    </div>
                                    <div class="col-md-2 col-lg-2 col-sm-12">
                                        <label for="">Customer Address</label>
                                        <input type="text" id="" class="form-control" name="customer_address" required>
                                    </div>
                                    <div class="col-md-3 col-lg-3 col-sm-12">
                                        <label for="">Invoice Number</label>
                                        <input type="text" id="" class="form-control" name="invoice_no" value="INV-<?= (rand(001, 10000)); ?>">
                                    </div>
                                    <div class="col-md-2 col-lg-2 col-sm-12">
                                        <label for="">Payment Type</label>
                                        <select name="payment_type" id="" class="form-control">
                                            <option value="">Choose ...</option>
                                            <option value="cash payment">Cash Payment</option>
                                            <option value="net banking">Net Banking</option>
                                            <option value="payment due">Payment Due</option>
                                        </select>
                                    </div>
                                    <div class="col-md-2 col-lg-2 col-sm-12">
                                        <label for="">Date</label>
                                        <input type="date" id="" class="form-control" name="date_in" value="<?= date('m-d-Y'); ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="well">
                                <div class="row">
                                    <div class="col-md-4 col-lg-4 col-sm-12">
                                        <label for="">Medicine Name</label>
                                        <select name="medicine_name" id="" class="form-control">
                                            <option value="">Choose ...</option>
                                            <?php
                                            $select = mysqli_query($connection, "SELECT * FROM `medicines`");
                                            while ($fetch = mysqli_fetch_array($select)) {
                                                echo "<option value='" . $fetch['NAME'] . "'>" . $fetch['NAME'] . " - <small> Generic Name :</small>  " . $fetch['GENERIC_NAME'] . "</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="col-md-3 col-lg-3 col-sm-12">
                                        <label for="">Quantity</label>
                                        <input type="text" id="" class="form-control" name="quantity" required>
                                    </div>
                                    <div class="col-md-2 col-lg-2 col-sm-12">
                                        <label for="">Discount</label>
                                        <input type="text" id="" class="form-control" name="discount" required>
                                    </div>
                                    <div class="col-md-3 col-lg-3 col-sm-12">
                                        <label for="">Total</label>
                                        <input type="text" id="" class="form-control" name="packing" disabled>
                                    </div>
                                </div>
                                <br>
                                <button type="submit" class="btn btn-success" name="save">Save</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <br>
        <div class="row content">
            <div class="col-sm-12">
                <div class="well">
                    <center>
                        <p>copyright &copy;2023 <a href=”#”>Our Pharmacy Name Here</a> </p>
                    </center>
                </div>
            </div>
        </div>
    </div>
</body>

</html>