<?php
session_start();
$id = $_SESSION['id'];
if ($id == "") {
    echo "<script>window.location.href='login.php'</script>";
}
?>
<?php
include('includes/connection.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Pharmacy System || Manage Invoice</title>
    <!-- include all link & script up Here-->
    <?php include("includes/script_up.php"); ?>
</head>

<body>
    <!-- include toggle botton Nav links Here -->
    <?php include("includes/side_nav_toggle.php"); ?>
    <!-- Home page dashboard Here -->
    <div class="container-fluid">
        <div class="row content">
            <div class="col-sm-3 sidenav hidden-xs">
                <?php include("includes/side_bar.php"); ?>
            </div>
            <br>

            <div class="col-sm-9">
                <div class="well">
                    <h4>Pharmacy Name Here || <small>Manage Invoice</small></h4>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="well">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">Invoice No</th>
                                        <th scope="col">Customer</th>
                                        <th scope="col">Date</th>
                                        <th scope="col">Total</th>
                                        <th scope="col">Discount</th>
                                        <th scope="col">Net Total</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $select = mysqli_query($connection, "SELECT * FROM `invoices`");
                                    $i = 0;
                                    while ($fetch = mysqli_fetch_array($select)) {
                                        $i++;
                                    ?>
                                        <tr>
                                            <td><?= $fetch['INVOICE_ID']; ?></td>
                                            <td><?= $fetch['CUSTOMER_ID']; ?></td>
                                            <td><?= $fetch['INVOICE_DATE']; ?></td>
                                            <td><?= $fetch['TOTAL_AMOUNT']; ?></td>
                                            <td><?= $fetch['TOTAL_DISCOUNT']; ?></td>
                                            <td><?= $fetch['NET_TOTAL']; ?></td>
                                            <td><a href="preview-invoice.php?id=<?= $fetch['INVOICE_ID']; ?>" class="btn btn-info" title="Print"><i class="fa fa-file-pdf-o" aria-hidden="true">Preview Invoice</i></a></td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <div class="row content">
                <div class="col-sm-12">
                    <div class="well">
                        <center>
                            <p>copyright &copy;2023 <a href=”#”>Our Pharmacy Name Here</a> </p>
                        </center>
                    </div>
                </div>
            </div>
        </div>

</body>

</html>