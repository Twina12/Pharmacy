<?php
// error handling
error_reporting(0);
// Database Connection Credentials
$server = "localhost";
$username = "root";
$password = "";
$databasename = "pharmacy";
// Database Connetion Query
$connection = mysqli_connect($server, $username, $password, $databasename);
if (!$connection) {
    // Error Message
    echo "Database Connection Error";
}
