 <nav class="navbar navbar-inverse visible-xs">
     <div class="container-fluid">
         <div class="navbar-header">
             <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                 <span class="icon-bar"></span>
                 <span class="icon-bar"></span>
                 <span class="icon-bar"></span>
             </button>
             <a class="navbar-brand" href="#">Logo</a>
         </div>
         <div class="collapse navbar-collapse" id="myNavbar">
             <ul class="nav navbar-nav">
                 <li class="active"><a href="#">Dashboard</a></li>
                 <li><a href="#">Invoice</a></li>
                 <li><a href="#">Customer</a></li>
                 <li><a href="#">Medicines</a></li>
                 <li><a href="#">Purchase</a></li>
                 <li><a href="#">Users</a>
                     <ul style="list-style-type:circle;">
                         <a href="add_user.php">Add User</a>
                         <a href="#">All Users</a>
                     </ul>
                 </li>

             </ul>
         </div>
     </div>
 </nav>