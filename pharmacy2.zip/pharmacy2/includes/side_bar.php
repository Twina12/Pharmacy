 <h2>Logo</h2>
 <ul class="nav nav-pills nav-stacked">
     <li class="active"><a href="#section1">Dashboard</a></li>
     <li><a href="#">Invoice</a>
         <ul style="list-style-type:circle;">
             <li><a href="add-invoice.php">Add Invoice</a></li>
             <li><a href="manage-invoice.php">Manage Invoice</a></li>
         </ul>
     </li>

     <li><a href="#">Medicines</a>
         <ul style="list-style-type:circle;">
             <li><a href="add-medicine.php">Add Medicine</a></li>
             <li><a href="manage-medicine.php">Manage Medicine</a></li>
             <li><a href="manage-medicine-stock.php">Manage Medicine Stock</a></li>

         </ul>
     </li>
     <li><a href="#">Purchase</a>
         <ul style="list-style-type:circle;">
             <li><a href="supplier.php">Supplier</a></li>
             <li><a href="add-purchase.php">Add Purchase</a></li>
             <li><a href="manage-purchase.php">Manage Purchase</a></li>
         </ul>
     </li>
     <li><a href="#">Users</a>
         <ul style="list-style-type:circle;">
             <li><a href="add_user.php">Add User</a></li>
             <li><a href="all_users.php">All Users</a></li>
         </ul>
     </li>
     <li><a href="logout.php">Logout</a></li>
 </ul><br>