<?php
include('includes/connection.php');
$user_id = $_GET['id'];
$delete_supplier = mysqli_query($connection, "DELETE FROM `medicines_stock` WHERE ID='$user_id'");
if ($delete_supplier) {
    echo "<script>window.location.href='manage-medicine-stock.php';</script>";
}
