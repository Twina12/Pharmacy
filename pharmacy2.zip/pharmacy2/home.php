<?php
session_start();
$id = $_SESSION['id'];
if ($id == "") {
    echo "<script>window.location.href='login.php'</script>";
}
include('includes/connection.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Pharmacy System || Home</title>
    <!-- include all link & script up Here-->
    <?php include("includes/script_up.php"); ?>
</head>

<body>
    <!-- include toggle botton Nav links Here -->
    <?php include("includes/side_nav_toggle.php"); ?>
    <!-- Home page dashboard Here -->
    <div class="container-fluid">
        <div class="row content">
            <div class="col-sm-3 sidenav hidden-xs">
                <?php include("includes/side_bar.php"); ?>
            </div>
            <br>

            <div class="col-sm-9">
                <div class="well">
                    <h4>Dashboard</h4>
                    <p>Some text..</p>
                </div>
                <div class="row">
                    <!-- invoice Counter Here -->
                    <?php
                    $select = mysqli_query($connection, "SELECT count(INVOICE_ID) as idadi FROM `invoices`");
                    $fetch = mysqli_fetch_array($select);
                    ?>
                    <div class="col-sm-3">
                        <div class="well">
                            <h4>Invoice</h4>
                            <p><?= $fetch['idadi']; ?></p>
                        </div>
                    </div>
                    <!-- Medicines Counter Here -->
                    <?php
                    $select = mysqli_query($connection, "SELECT count(ID) as idadi FROM `medicines`");
                    $fetch = mysqli_fetch_array($select);
                    ?>
                    <div class="col-sm-3">
                        <div class="well">
                            <h4>Medicines</h4>
                            <p><?= $fetch['idadi']; ?></p>
                        </div>
                    </div>
                    <!-- Purchase Counter Here -->
                    <?php
                    $select = mysqli_query($connection, "SELECT count(VOUCHER_NUMBER) as idadi FROM `purchases`");
                    $fetch = mysqli_fetch_array($select);
                    ?>
                    <div class="col-sm-3">
                        <div class="well">
                            <h4>Purchases</h4>
                            <p><?= $fetch['idadi']; ?></p>
                        </div>
                    </div>
                    <!-- Users Counter Here -->
                    <?php
                    $select = mysqli_query($connection, "SELECT count(id) as idadi FROM `users`");
                    $fetch = mysqli_fetch_array($select);
                    ?>
                    <div class="col-sm-3">
                        <div class="well">
                            <h4>Users</h4>
                            <p><?= $fetch['idadi']; ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <br>
        <div class="row content">
            <div class="col-sm-12">
                <div class="well">
                    <center>
                        <p>copyright &copy;2023 <a href=”#”>Our Pharmacy Name Here</a> </p>
                    </center>
                </div>
            </div>
        </div>
    </div>

</body>

</html>