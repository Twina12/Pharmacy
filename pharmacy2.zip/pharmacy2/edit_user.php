<?php
session_start();
$id = $_SESSION['id'];
if ($id == "") {
    echo "<script>window.location.href='login.php'</script>";
}
include("includes/connection.php");
if (isset($_POST['save'])) {
    $full_name = $_POST['full_name'];
    $user_id = $_POST['user_id'];
    $phone_number = $_POST['phone_number'];
    $email = $_POST['email'];
    $select = mysqli_query($connection, "SELECT count(id) as idadi FROM `users` WHERE email='$email' or phone='$phone_number'");
    $fetch = mysqli_fetch_array($select);
    if ($fetch['idadi'] > 1) {
        echo "<script>alert('Oops!! Email or Phone Number Already Used,Please Change')</script>";
    } else {
        $update_user = mysqli_query($connection, "UPDATE `users` SET `fullname`='$full_name',`phone`='$phone_number',`email`='$email' WHERE id='$user_id'");
        $update_login = mysqli_query($connection, "UPDATE `login` SET `email`='$email' WHERE user_id='$user_id'");
        if ($update_login and $update_user) {
            echo "<script>alert('User Successful Updated');</script>";
        } else {
            echo "<script>alert('Oops!! Something wrong happen,Try Again')</script>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Pharmacy System || Edit User</title>
    <!-- include all link & script up Here-->
    <?php include("includes/script_up.php"); ?>
</head>

<body>
    <!-- include toggle botton Nav links Here -->
    <?php include("includes/side_nav_toggle.php"); ?>
    <!-- Home page dashboard Here -->
    <div class="container-fluid">
        <div class="row content">
            <div class="col-sm-3 sidenav hidden-xs">
                <?php include("includes/side_bar.php"); ?>
            </div>
            <br>

            <div class="col-sm-9">
                <div class="well">
                    <h4>Pharmacy Name Here || <small>Edit User</small></h4>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="well">
                            <!-- add user form here -->
                            <?php
                            $id = $_GET['id'];
                            $select = mysqli_query($connection, "SELECT * FROM `users` WHERE id='$id'");
                            $fetch = mysqli_fetch_array($select);
                            ?>
                            <form action="" method="post">
                                <input type="hidden" name="user_id" id="" value="<?= $id; ?>">
                                <label for="">Full Name</label>
                                <input type="text" id="" class="form-control" name="full_name" value="<?= $fetch['fullname']; ?>">
                                <label for="">Phone Number</label>
                                <input type="text" name="phone_number" id="" class="form-control" value="<?= $fetch['phone']; ?>">
                                <label for="">Email</label>
                                <input type="text" name="email" id="" class="form-control" value="<?= $fetch['email']; ?>">
                                <br>
                                <button class="btn btn-primary" type="submit" name="save">UPDATE</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <div class="row content">
                <div class="col-sm-12">
                    <div class="well">
                        <center>
                            <p>copyright &copy;2023 <a href=”#”>Our Pharmacy Name Here</a> </p>
                        </center>
                    </div>
                </div>
            </div>
        </div>

</body>

</html>