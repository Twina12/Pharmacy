<?php
include('includes/connection.php');
$user_id = $_GET['id'];
$delete_supplier = mysqli_query($connection, "DELETE FROM `purchases` WHERE VOUCHER_NUMBER='$user_id'");
if ($delete_supplier) {
    echo "<script>window.location.href='manage-purchase.php';</script>";
}
