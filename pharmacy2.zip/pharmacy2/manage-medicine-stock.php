<?php
session_start();
$id = $_SESSION['id'];
if ($id == "") {
    echo "<script>window.location.href='login.php'</script>";
}
include('includes/connection.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Pharmacy System || Manage Medicines Stock</title>
    <!-- include all link & script up Here-->
    <?php include("includes/script_up.php"); ?>
</head>

<body>
    <!-- include toggle botton Nav links Here -->
    <?php include("includes/side_nav_toggle.php"); ?>
    <!-- Home page dashboard Here -->
    <div class="container-fluid">
        <div class="row content">
            <div class="col-sm-3 sidenav hidden-xs">
                <?php include("includes/side_bar.php"); ?>
            </div>
            <br>

            <div class="col-sm-9">
                <div class="well">
                    <h4>Pharmacy Name Here || <small>Manage Medicines Stock</small></h4>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="well">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">SL</th>
                                        <th scope="col">Medicine Name</th>
                                        <th scopr="col">PACKING</th>
                                        <th scope="col">Generic Name</th>
                                        <th scope="col">Batch ID</th>
                                        <th scope="col">Expire Date</th>
                                        <th scope="col">Supplier</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">MRP</th>
                                        <th scope="col">Rate</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $select = mysqli_query($connection, "SELECT medicines.NAME,medicines.GENERIC_NAME,medicines.PACKING,medicines_stock.BATCH_ID,medicines_stock.EXPIRY_DATE,medicines.SUPPLIER_NAME,medicines_stock.QUANTITY,medicines_stock.MRP,medicines_stock.RATE,medicines_stock.ID FROM medicines_stock JOIN purchases on purchases.VOUCHER_NUMBER=medicines_stock.ID JOIN medicines ON medicines.NAME=medicines_stock.NAME");
                                    $i = 0;
                                    while ($fetch = mysqli_fetch_array($select)) {
                                        $i++;
                                    ?>
                                        <tr>
                                            <th scope="row"><?= $i; ?></th>
                                            <td><?= $fetch['NAME']; ?></td>
                                            <td><?= $fetch['GENERIC_NAME']; ?></td>
                                            <td><?= $fetch['PACKING']; ?></td>
                                            <td><?= $fetch['BATCH_ID']; ?></td>
                                            <td><?= $fetch['EXPIRY_DATE']; ?></td>
                                            <td><?= $fetch['SUPPLIER_NAME']; ?></td>
                                            <td><?= $fetch['QUANTITY']; ?></td>
                                            <td><?= $fetch['MRP']; ?></td>
                                            <td><?= $fetch['RATE']; ?></td>
                                            <td><a href="update-medicine-stock.php?id=<?= $fetch['ID']; ?>" class="btn btn-primary" title="Delete"><i class="fa fa-pen" aria-hidden="true"></i></a> <a href="delete-medicine-stock.php?id=<?= $fetch['ID']; ?>" class="btn btn-danger" title="Delete"><i class="fa fa-trash" aria-hidden="true"></i></a></td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <div class="row content">
                <div class="col-sm-12">
                    <div class="well">
                        <center>
                            <p>copyright &copy;2023 <a href=”#”>Our Pharmacy Name Here</a> </p>
                        </center>
                    </div>
                </div>
            </div>
        </div>

</body>

</html>