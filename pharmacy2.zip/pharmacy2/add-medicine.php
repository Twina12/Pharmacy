<?php
session_start();
$id = $_SESSION['id'];
if ($id == "") {
    echo "<script>window.location.href='login.php'</script>";
}
include("includes/connection.php");
if (isset($_POST['save'])) {
    $full_name = ucwords($_POST['full_name']);
    $packing = htmlspecialchars($_POST['packing']);
    $generic_name = htmlspecialchars($_POST['generic_name']);
    $supplier = htmlspecialchars($_POST['supplier']);
    $select = mysqli_query($connection, "SELECT count(ID) as idadi FROM `medicines` WHERE NAME='$full_name'");
    $fetch = mysqli_fetch_array($select);
    if ($fetch['idadi'] > 0) {
        echo "<script>alert('Oops!! Medicine Exist')</script>";
    } else {
        $insert = mysqli_query($connection, "INSERT INTO `medicines`(`NAME`, `PACKING`, `GENERIC_NAME`, `SUPPLIER_NAME`) VALUES ('$full_name','$packing','$generic_name','$supplier')");
        if ($insert) {
            echo "<script>alert('Medicine Successful Registered');</script>";
        } else {
            echo "<script>alert('Oops!! Something wrong happen,Try Again')</script>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Pharmacy System || Add Medicine</title>
    <!-- include all link & script up Here-->
    <?php include("includes/script_up.php"); ?>
</head>

<body>
    <!-- include toggle botton Nav links Here -->
    <?php include("includes/side_nav_toggle.php"); ?>
    <!-- Home page dashboard Here -->
    <div class="container-fluid">
        <div class="row content">
            <div class="col-sm-3 sidenav hidden-xs">
                <?php include("includes/side_bar.php"); ?>
            </div>
            <br>

            <div class="col-sm-9">
                <div class="well">
                    <h4>Pharmacy Name Here || <small>Add Medicine</small></h4>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="well">
                            <!-- add user form here -->
                            <form action="" method="post">
                                <label for="">Medicine Name</label>
                                <input type="text" id="" class="form-control" name="full_name" required>
                                <label for="">Packing</label>
                                <input type="text" name="packing" id="" class="form-control" placeholder="eg 10 TAB" required>
                                <label for="">Generic Name</label>
                                <input type="text" name="generic_name" id="" class="form-control" required>
                                <label for="">Supplier</label>
                                <select name="supplier" id="" class="form-control">
                                    <option value="">Choose ...</option>
                                    <?php
                                    $select = mysqli_query($connection, "SELECT * FROM `suppliers`");
                                    while ($fetch = mysqli_fetch_array($select)) {
                                        echo "<option value='" . $fetch['ID'] . "'>" . $fetch['NAME'] . "</option>";
                                    }
                                    ?>
                                </select>
                                <br>
                                <button class="btn btn-primary" type="submit" name="save">SAVE</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <div class="row content">
                <div class="col-sm-12">
                    <div class="well">
                        <center>
                            <p>copyright &copy;2023 <a href=”#”>Our Pharmacy Name Here</a> </p>
                        </center>
                    </div>
                </div>
            </div>
        </div>

</body>

</html>