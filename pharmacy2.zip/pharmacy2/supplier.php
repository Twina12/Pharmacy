<?php
session_start();
$id = $_SESSION['id'];
if ($id == "") {
    echo "<script>window.location.href='login.php'</script>";
}
include('includes/connection.php');
if (isset($_POST['save'])) {
    $full_name = htmlspecialchars($_POST['full_name']);
    $phone_number = htmlspecialchars($_POST['phone_number']);
    $email = htmlspecialchars($_POST['email']);
    $address = htmlspecialchars($_POST['address']);
    $select = mysqli_query($connection, "SELECT count(id) as idadi FROM `suppliers` WHERE EMAIL='$email' or CONTACT_NUMBER='$phone_number'");
    $fetch = mysqli_fetch_array($select);
    if ($fetch['idadi'] > 0) {
        echo "<script>alert('Oops!! Email or Phone Number Already Used,Please Change')</script>";
    } else {
        $insert_supplier = mysqli_query($connection, "INSERT INTO `suppliers`(`NAME`, `EMAIL`, `CONTACT_NUMBER`, `ADDRESS`) VALUES ('$full_name','$email','$phone_number','$address')");
        if ($insert_supplier) {
            echo "<script>alert('Supplier Successful Registered');</script>";
        } else {
            echo "<script>alert('Oops!! Something wrong happen,Try Again')</script>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Pharmacy System || Manage Supplier</title>
    <!-- include all link & script up Here-->
    <?php include("includes/script_up.php"); ?>
</head>

<body>
    <!-- include toggle botton Nav links Here -->
    <?php include("includes/side_nav_toggle.php"); ?>
    <!-- Home page dashboard Here -->
    <div class="container-fluid">
        <div class="row content">
            <div class="col-sm-3 sidenav hidden-xs">
                <?php include("includes/side_bar.php"); ?>
            </div>
            <br>

            <div class="col-sm-9">
                <div class="well">
                    <h4>Pharmacy Name Here || <small>Manage Supplier</small></h4>
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                        New Supplier
                    </button>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="well">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col"> Name</th>
                                        <th scope="col">Phone Number</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Address</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $select = mysqli_query($connection, "SELECT * FROM `suppliers`");
                                    $i = 0;
                                    while ($fetch = mysqli_fetch_array($select)) {
                                        $i++;
                                    ?>
                                        <tr>
                                            <th scope="row"><?= $i; ?></th>
                                            <td><?= $fetch['NAME']; ?></td>
                                            <td><?= $fetch['CONTACT_NUMBER']; ?></td>
                                            <td><?= $fetch['EMAIL']; ?></td>
                                            <td><?= $fetch['ADDRESS']; ?></td>
                                            <td><a href="delete-supplier.php?id=<?= $fetch['ID']; ?>" class="btn btn-danger" title="Delete"><i class="fa fa-trash" aria-hidden="true"></i></a></td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <div class="row content">
                <div class="col-sm-12">
                    <div class="well">
                        <center>
                            <p>copyright &copy;2023 <a href=”#”>Our Pharmacy Name Here</a> </p>
                        </center>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Add New Supplier</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form action="" method="post">
                        <div class="modal-body">
                            <label for="">Supplier Name</label>
                            <input type="text" id="" class="form-control" name="full_name" required>
                            <label for="">Supplier Phone Number</label>
                            <input type="text" name="phone_number" id="" class="form-control" required>
                            <label for="">Supplier Email</label>
                            <input type="text" name="email" id="" class="form-control" required>
                            <label for="">Supplier Address</label>
                            <textarea name="address" id="" cols="5" rows="5" class="form-control" required></textarea>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary" name="save">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
</body>

</html>