<?php
include('includes/connection.php');
$user_id = $_GET['id'];
$delete_user = mysqli_query($connection, "DELETE FROM `users` WHERE id='$user_id'");
$delete_user_login = mysqli_query($connection, "DELETE FROM `login` WHERE user_id='$user_id'");
if ($delete_user and $delete_user_login) {
    echo "<script>window.location.href='all_users.php';</script>";
}
