<?php
session_start();
$id = $_SESSION['id'];
if ($id == "") {
    echo "<script>window.location.href='login.php'</script>";
}
include('includes/connection.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Pharmacy System || Preview Invoice</title>
    <!-- include all link & script up Here-->
    <?php include("includes/script_up.php"); ?>
    <script>
        function printDiv() {
            var divContents = document.getElementById("GFG").innerHTML;
            var a = window.open('', '', 'height=500, width=1500');
            a.document.write('<html>');
            a.document.write('<body > <h3>Pharmacy Name Here </h3> <br>');
            a.document.write(divContents);
            a.document.write('</body></html>');
            a.document.close();
            a.print();
        }
    </script>
</head>

<body>
    <!-- include toggle botton Nav links Here -->
    <?php include("includes/side_nav_toggle.php"); ?>
    <!-- Home page dashboard Here -->
    <div class="container-fluid">
        <div class="row content">
            <div class="col-sm-3 sidenav hidden-xs">
                <?php include("includes/side_bar.php"); ?>
            </div>
            <br>

            <div class="col-sm-9">
                <div class="well">
                    <h4>Pharmacy Name Here || <small>Preview Invoice</small></h4>
                    <button type="button" onclick="printDiv()" class="btn btn-primary">Print</button>
                </div>
                <?php
                $id = $_GET['id'];
                $select = mysqli_query($connection, "SELECT * FROM `invoices` WHERE INVOICE_ID='$id'");
                $fetch = mysqli_fetch_array($select);
                ?>


                <div class="row" id="GFG">
                    <div class="col-sm-12">
                        <div class="well">
                            <div class="row">
                                <div class="col-md-1"></div>
                                <div class="col-md-10 h3" style="color: #ff5252;"><span class="float-right">Invoice Number : <?= $id; ?></span></div>
                            </div>
                            <div class="row text-center">
                                <hr class="col-md-10" style="padding: 0px; border-top: 2px solid  #ff5252;">
                            </div>
                            <div class="row">
                                <div class="col-md-1"></div>
                                <div class="col-md-4">
                                    <span class="h4">Customer Details : </span><?= $fetch['CUSTOMER_ID']; ?><br><br>
                                    <span class="font-weight-bold">Net Total : </span><?= $fetch['NET_TOTAL']; ?><br>
                                    <span class="font-weight-bold">Total Discount : </span><?= $fetch['TOTAL_DISCOUNT']; ?><br>
                                    <span class="font-weight-bold">Total Amount : </span><?= $fetch['TOTAL_AMOUNT']; ?><br>
                                    <span class="font-weight-bold">Invoice Date : </span><?= $fetch['INVOICE_DATE']; ?><br>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <div class="row content">
                <div class="col-sm-12">
                    <div class="well">
                        <center>
                            <p>copyright &copy;2023 <a href=”#”>Our Pharmacy Name Here</a> </p>
                        </center>
                    </div>
                </div>
            </div>
        </div>

</body>

</html>