<?php
session_start();
include('includes/connection.php');
if (isset($_POST['save'])) {
    $_SESSION['email'] = $_POST['email'];
    $_SESSION['password'] = $_POST['password'];
    $select = mysqli_query($connection, "SELECT * FROM `login` WHERE email='" . $_SESSION['email'] . "'");
    $fetch = mysqli_fetch_array($select);
    $hash = $fetch['password'];
    if (password_verify($_SESSION['password'], $hash)) {
        $_SESSION['id'] = $fetch['id'];
        echo "<script>window.location.href='home.php';</script>";
    } else {
        echo "<script>alert('Incorrect Password Or Email');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Pharmacy System || Login</title>
    <!-- include all link & script up Here-->
    <?php include("includes/script_up.php"); ?>
</head>

<body>
    <!-- include toggle botton Nav links Here -->
    <!-- Home page dashboard Here -->
    <div class="container-fluid">
        <div class="row content">
            <div class="col-sm-4">
            </div>
            <div class="col-sm-4">
                <br><br>
                <div class="well">

                    <h3>Sign Up</h3>
                    <form action="" method="post">
                        <label for="">Email</label>
                        <input type="text" id="" class="form-control" name="email" placeholder="eg. admin@gmail.com" required>
                        <label for="">Password</label>
                        <input type="password" name="password" id="" class="form-control" required><br>
                        <button class="btn btn-primary" type="submit" name="save">Login</button>
                    </form>
                </div>
            </div>
        </div>
        <br>
        <div class="row content">
            <div class="col-sm-12">
                <div class="well">
                    <center>
                        <p>copyright &copy;2023 <a href=”#”>Our Pharmacy Name Here</a> </p>
                    </center>
                </div>
            </div>
        </div>
    </div>

</body>

</html>