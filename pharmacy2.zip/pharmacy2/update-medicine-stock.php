<?php
session_start();
$id = $_SESSION['id'];
if ($id == "") {
    echo "<script>window.location.href='login.php'</script>";
}
include("includes/connection.php");
if (isset($_POST['save'])) {
    $user_id = $_POST['user_id'];
    $batch_id = $_POST['batch_id'];
    $quantity = $_POST['quantity'];
    $mrp = $_POST['mrp'];
    $rate = $_POST['rate'];
    $update_user = mysqli_query($connection, "UPDATE `medicines_stock` SET `BATCH_ID`='$batch_id',`QUANTITY`='$quantity',`MRP`='$mrp',`RATE`='$rate' WHERE ID='$user_id'");
    $update_login = mysqli_query($connection, "UPDATE `login` SET `email`='$email' WHERE user_id='$user_id'");
    if ($update_login and $update_user) {
        echo "<script>alert('User Successful Updated');window.location.href='manage-medicine-stock.php'</script>";
    } else {
        echo "<script>alert('Oops!! Something wrong happen,Try Again')</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Pharmacy System || Update Medicine Stock</title>
    <!-- include all link & script up Here-->
    <?php include("includes/script_up.php"); ?>
</head>

<body>
    <!-- include toggle botton Nav links Here -->
    <?php include("includes/side_nav_toggle.php"); ?>
    <!-- Home page dashboard Here -->
    <div class="container-fluid">
        <div class="row content">
            <div class="col-sm-3 sidenav hidden-xs">
                <?php include("includes/side_bar.php"); ?>
            </div>
            <br>

            <div class="col-sm-9">
                <div class="well">
                    <h4>Pharmacy Name Here || <small>Update Medicine Stock</small></h4>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="well">
                            <!-- add user form here -->
                            <?php
                            $id = $_GET['id'];
                            $select = mysqli_query($connection, "SELECT medicines.NAME,medicines.GENERIC_NAME,medicines.PACKING,medicines_stock.BATCH_ID,medicines_stock.EXPIRY_DATE,medicines.SUPPLIER_NAME,medicines_stock.QUANTITY,medicines_stock.MRP,medicines_stock.RATE,medicines_stock.ID FROM medicines_stock JOIN purchases on purchases.VOUCHER_NUMBER=medicines_stock.ID JOIN medicines ON medicines.NAME=medicines_stock.NAME WHERE medicines_stock.ID='$id'");
                            $fetch = mysqli_fetch_array($select);
                            ?>
                            <form action="" method="post">
                                <input type="hidden" name="user_id" id="" value="<?= $id; ?>">
                                <label for="">Medicine Name</label>
                                <input type="text" id="" class="form-control" name="full_name" value="<?= $fetch['NAME']; ?>" disabled>
                                <label for="">Generic Name</label>
                                <input type="text" id="" class="form-control" name="full_name" value="<?= $fetch['GENERIC_NAME']; ?>" disabled>
                                <label for="">Batch ID</label>
                                <input type="text" name="batch_id" id="" class="form-control" value="<?= $fetch['BATCH_ID']; ?>">
                                <label for="">Quantity</label>
                                <input type="text" name="quantity" id="" class="form-control" value="<?= $fetch['QUANTITY']; ?>">
                                <label for="">MRP</label>
                                <input type="text" name="mrp" id="" class="form-control" value="<?= $fetch['MRP']; ?>">
                                <label for="">Rate</label>
                                <input type="text" name="rate" id="" class="form-control" value="<?= $fetch['RATE']; ?>">
                                <br>
                                <button class="btn btn-primary" type="submit" name="save">UPDATE</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <div class="row content">
                <div class="col-sm-12">
                    <div class="well">
                        <center>
                            <p>copyright &copy;2023 <a href=”#”>Our Pharmacy Name Here</a> </p>
                        </center>
                    </div>
                </div>
            </div>
        </div>

</body>

</html>