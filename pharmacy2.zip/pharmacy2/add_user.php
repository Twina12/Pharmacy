<?php
session_start();
$id = $_SESSION['id'];
if ($id == "") {
    echo "<script>window.location.href='login.php'</script>";
}
include("includes/connection.php");
if (isset($_POST['save'])) {
    $full_name = ucwords($_POST['full_name']);
    $phone_number = htmlspecialchars($_POST['phone_number']);
    $email = htmlspecialchars($_POST['email']);
    $password = $_POST['password'];
    $re_password = $_POST['re_password'];
    if ($password == $re_password) {
        $select = mysqli_query($connection, "SELECT count(id) as idadi FROM `users` WHERE email='$email' or phone='$phone_number'");
        $fetch = mysqli_fetch_array($select);
        if ($fetch['idadi'] > 0) {
            echo "<script>alert('Oops!! Email or Phone Number Already Used,Please Change')</script>";
        } else {
            $$insert_user = mysqli_query($connection, "INSERT INTO `users`(`fullname`, `phone`, `email`) VALUES ('$full_name','$phone_number','$email')");
            $last_id = mysqli_insert_id($connection);
            $pass = password_hash($password, PASSWORD_DEFAULT);
            $insert_login = mysqli_query($connection, "INSERT INTO `login`(`user_id`, `email`, `password`) VALUES ('$last_id','$email','$pass')");
            if ($insert_login) {
                echo "<script>alert('User Successful Registered');</script>";
            } else {
                echo "<script>alert('Oops!! Something wrong happen,Try Again')</script>";
            }
        }
    } else {
        echo "<script>alert('Password And Re-Password Not Match')</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Pharmacy System || Add User</title>
    <!-- include all link & script up Here-->
    <?php include("includes/script_up.php"); ?>
</head>

<body>
    <!-- include toggle botton Nav links Here -->
    <?php include("includes/side_nav_toggle.php"); ?>
    <!-- Home page dashboard Here -->
    <div class="container-fluid">
        <div class="row content">
            <div class="col-sm-3 sidenav hidden-xs">
                <?php include("includes/side_bar.php"); ?>
            </div>
            <br>

            <div class="col-sm-9">
                <div class="well">
                    <h4>Pharmacy Name Here || <small>Add User</small></h4>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="well">
                            <!-- add user form here -->
                            <form action="" method="post">
                                <label for="">Full Name</label>
                                <input type="text" id="" class="form-control" name="full_name" required>
                                <label for="">Phone Number</label>
                                <input type="text" name="phone_number" id="" class="form-control" required>
                                <label for="">Email</label>
                                <input type="email" name="email" id="" class="form-control" required>
                                <label for="">Password</label>
                                <input type="text" name="password" id="" class="form-control" required>
                                <label for="">Re-password</label>
                                <input type="text" name="re_password" id="" class="form-control" required>
                                <br>
                                <button class="btn btn-primary" type="submit" name="save">SAVE</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <div class="row content">
                <div class="col-sm-12">
                    <div class="well">
                        <center>
                            <p>copyright &copy;2023 <a href=”#”>Our Pharmacy Name Here</a> </p>
                        </center>
                    </div>
                </div>
            </div>
        </div>

</body>

</html>