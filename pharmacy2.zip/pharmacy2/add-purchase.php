<?php
session_start();
$id = $_SESSION['id'];
if ($id == "") {
    echo "<script>window.location.href='login.php'</script>";
}
include("includes/connection.php");
if (isset($_POST['save'])) {
    $supplier = htmlspecialchars($_POST['supplier']);
    $invoice_no = htmlspecialchars($_POST['invoice_no']);
    $payment_type = htmlspecialchars($_POST['payment_type']);
    $date_in = htmlspecialchars($_POST['date_in']);
    $medicine_name = htmlspecialchars($_POST['medicine_name']);
    $packing = htmlspecialchars($_POST['packing']);
    $batch_id = htmlspecialchars($_POST['batch_id']);
    $expire_date = htmlspecialchars($_POST['expire_date']);
    $quantity = htmlspecialchars($_POST['quantity']);
    $mrp = htmlspecialchars($_POST['mrp']);
    $rate = htmlspecialchars($_POST['rate']);
    $amount = $quantity * $rate;
    $select = mysqli_query($connection, "SELECT count(id) as idadi FROM `medicines_stock` WHERE BATCH_ID='$batch_id' and NAME='$medicine_name'");
    $fetch = mysqli_fetch_array($select);
    if ($fetch['idadi'] > 0) {
        echo "<script>alert('Oops!! Email or Phone Number Already Used,Please Change')</script>";
    } else {
        $insert_stock = mysqli_query($connection, "INSERT INTO `medicines_stock`(`NAME`, `BATCH_ID`, `EXPIRY_DATE`, `QUANTITY`, `MRP`, `RATE`) VALUES ('$medicine_name','$batch_id','$expire_date','$quantity','$mrp','$rate')");
        $last_id = mysqli_insert_id($connection);
        $insert = mysqli_query($connection, "INSERT INTO `purchases`(`SUPPLIER_NAME`, `INVOICE_NUMBER`, `VOUCHER_NUMBER`, `PURCHASE_DATE`, `TOTAL_AMOUNT`, `PAYMENT_STATUS`) VALUES ('$supplier','$invoice_no','$last_id','$date_in','$amount','$payment_type')");
        if ($insert and $insert_stock) {
            echo "<script>alert('Purchaseed Succefully');</script>";
        } else {
            echo "<script>alert('Oops!! Something wrong happen,Try Again')</script>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Pharmacy System || Add Purchase</title>
    <!-- include all link & script up Here-->
    <?php include("includes/script_up.php"); ?>
</head>

<body>
    <!-- include toggle botton Nav links Here -->
    <?php include("includes/side_nav_toggle.php"); ?>
    <!-- Home page dashboard Here -->
    <div class="container-fluid">
        <div class="row content">
            <div class="col-sm-3 sidenav hidden-xs">
                <?php include("includes/side_bar.php"); ?>
            </div>
            <br>

            <div class="col-sm-9">
                <div class="well">
                    <h4>Pharmacy Name Here || <small>Add Purchase</small></h4>
                </div>
                <div class="row">
                    <form action="" method="post">
                        <div class="col-sm-12">
                            <div class="well">
                                <!-- add user form here -->
                                <div class="row">
                                    <div class="col-md-3 col-lg-3 col-sm-12">
                                        <label for="">Supplier Name</label>
                                        <select name="supplier" id="" class="form-control">
                                            <option value="">Choose ...</option>
                                            <?php
                                            $select = mysqli_query($connection, "SELECT * FROM `suppliers`");
                                            while ($fetch = mysqli_fetch_array($select)) {
                                                echo "<option value='" . $fetch['NAME'] . "'>" . $fetch['NAME'] . "</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="col-md-3 col-lg-3 col-sm-12">
                                        <label for="">Invoice Number</label>
                                        <input type="text" id="" class="form-control" name="invoice_no" required>
                                    </div>
                                    <div class="col-md-3 col-lg-3 col-sm-12">
                                        <label for="">Payment Type</label>
                                        <select name="payment_type" id="" class="form-control">
                                            <option value="">Choose ...</option>
                                            <option value="cash payment">Cash Payment</option>
                                            <option value="net banking">Net Banking</option>
                                            <option value="payment due">Payment Due</option>
                                        </select>
                                    </div>
                                    <div class="col-md-3 col-lg-3 col-sm-12">
                                        <label for="">Date</label>
                                        <input type="date" id="" class="form-control" name="date_in" value="<?= date('m-d-Y'); ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="well">
                                <div class="row">
                                    <div class="col-md-3 col-lg-3 col-sm-12">
                                        <label for="">Medicine Name</label>
                                        <select name="medicine_name" id="" class="form-control">
                                            <option value="">Choose ...</option>
                                            <?php
                                            $select = mysqli_query($connection, "SELECT * FROM `medicines`");
                                            while ($fetch = mysqli_fetch_array($select)) {
                                                echo "<option value='" . $fetch['NAME'] . "'>" . $fetch['NAME'] . "</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="col-md-2 col-lg-2 col-sm-12">
                                        <label for="">Packing</label>
                                        <input type="text" id="" class="form-control" name="packing" required>
                                    </div>
                                    <div class="col-md-2 col-lg-2 col-sm-12">
                                        <label for="">Batch ID</label>
                                        <input type="text" id="" class="form-control" name="batch_id" required>
                                    </div>
                                    <div class="col-md-2 col-lg-2 col-sm-12">
                                        <label for="">Expire Date</label>
                                        <input type="date" id="" class="form-control" name="expire_date" required>
                                    </div>
                                    <div class="col-md-3 col-lg-3 col-sm-12">
                                        <label for="">Quantity</label>
                                        <input type="text" id="" class="form-control" name="quantity" value="0">
                                    </div>
                                    <div class="col-md-3 col-lg-3 col-sm-12">
                                        <label for="">MRP</label>
                                        <input type="text" id="" class="form-control" name="mrp">
                                    </div>
                                    <div class="col-md-3 col-lg-3 col-sm-12">
                                        <label for="">Rate</label>
                                        <input type="text" id="" class="form-control" name="rate">
                                    </div>
                                </div>
                                <br>
                                <button type="submit" class="btn btn-success" name="save">Save</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <br>
        <div class="row content">
            <div class="col-sm-12">
                <div class="well">
                    <center>
                        <p>copyright &copy;2023 <a href=”#”>Our Pharmacy Name Here</a> </p>
                    </center>
                </div>
            </div>
        </div>
    </div>
</body>

</html>