<?php
session_start();
$id = $_SESSION['id'];
if ($id == "") {
    echo "<script>window.location.href='login.php'</script>";
}
include('includes/connection.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Pharmacy System || Manage Medicines</title>
    <!-- include all link & script up Here-->
    <?php include("includes/script_up.php"); ?>
</head>

<body>
    <!-- include toggle botton Nav links Here -->
    <?php include("includes/side_nav_toggle.php"); ?>
    <!-- Home page dashboard Here -->
    <div class="container-fluid">
        <div class="row content">
            <div class="col-sm-3 sidenav hidden-xs">
                <?php include("includes/side_bar.php"); ?>
            </div>
            <br>

            <div class="col-sm-9">
                <div class="well">
                    <h4>Pharmacy Name Here || <small>Manage Medicines</small></h4>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="well">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Medicine Name</th>
                                        <th scope="col">Packing</th>
                                        <th scope="col">Generic Name</th>
                                        <th scope="col">Supplier</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $select = mysqli_query($connection, "SELECT m.*,s.NAME as supplier FROM `medicines` m JOIN suppliers s ON s.ID=m.SUPPLIER_NAME");
                                    $i = 0;
                                    while ($fetch = mysqli_fetch_array($select)) {
                                        $i++;
                                    ?>
                                        <tr>
                                            <th scope="row"><?= $i; ?></th>
                                            <td><?= $fetch['NAME']; ?></td>
                                            <td><?= $fetch['PACKING']; ?></td>
                                            <td><?= $fetch['GENERIC_NAME']; ?></td>
                                            <td><?= $fetch['supplier']; ?></td>
                                            <td><a href="delete-medicine.php?id=<?= $fetch['ID']; ?>" class="btn btn-danger" title="Delete"><i class="fa fa-trash" aria-hidden="true"></i></a></td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <div class="row content">
                <div class="col-sm-12">
                    <div class="well">
                        <center>
                            <p>copyright &copy;2023 <a href=”#”>Our Pharmacy Name Here</a> </p>
                        </center>
                    </div>
                </div>
            </div>
        </div>

</body>

</html>